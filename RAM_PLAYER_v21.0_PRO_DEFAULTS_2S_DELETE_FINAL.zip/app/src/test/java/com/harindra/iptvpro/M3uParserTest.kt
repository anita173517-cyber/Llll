package com.harindra.iptvpro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException
import java.io.Reader
import java.net.SocketTimeoutException
import java.util.Calendar
import java.util.TimeZone

/**
 * StreamX Media3 Pro v18.1 — Next-Gen Ultra Upgrade Complete Unit Test Suite:
 * Covers all existing v18.0/v18.1 parser/network/preloader/security/content-separation tests plus
 * LiveTvBackgroundPlaybackController, SearchIntelligenceEngine (typo-tolerant & multi-token search),
 * PlaylistHealthEngine & Smart Duplicate Detection, BackupRestoreEngine (SXBK_V19 validation),
 * PersonalizationEngine (Cinematic Hero selection), UiDensityMode, LiveChannelSortOrder,
 * and findPreviousEpisodeInSeries / findNextEpisodeInSeries.
 */
class M3uParserTest {

    @Test
    fun parsesMetadataAndChannelUrl() {
        val playlist = """#EXTM3U
#EXTINF:-1 tvg-id="news.in" tvg-logo="https://cdn.example/logo.png" group-title="News",India News HD
https://stream.example/news/index.m3u8
""".trimIndent()

        val channels = M3uParser.parse(playlist)
        assertEquals(1, channels.size)
        assertEquals("India News HD", channels[0].name)
        assertEquals("News", channels[0].category)
        assertEquals("news.in", channels[0].epgId)
        assertEquals("https://cdn.example/logo.png", channels[0].logoUrl)
        assertEquals("https://stream.example/news/index.m3u8", channels[0].streamUrl)
        assertEquals(ContentSourceType.M3U_LIVE, channels[0].sourceType)
        assertTrue(channels[0].isLiveTvChannel())
        assertFalse(channels[0].isVodMovie())
        assertFalse(channels[0].isSeriesEpisode())
    }

    @Test
    fun parsesUnquotedAttributesCustomChNoAndSmartCategoriesWhilePreservingM3uLiveType() {
        val playlist = """#EXTM3U
#EXTINF:-1 tvg-id=star.sports.hd tvg-chno=505,Star Cricket Live
https://stream.example/live/cricket.m3u8
#EXTINF:-1,Blockbuster Action Movie (2025) 1080p
https://stream.example/movie/user/pass/9001.mp4
""".trimIndent()

        val channels = M3uParser.parse(playlist)
        assertEquals(2, channels.size)
        assertEquals(505, channels[0].number)
        assertEquals("star.sports.hd", channels[0].epgId)
        assertEquals("Sports", channels[0].category)
        assertEquals(ContentSourceType.M3U_LIVE, channels[0].sourceType)
        assertEquals(EntertainmentSection.LIVE_TV, channels[0].primarySection())

        // Even if an M3U entry has a movie-like name or .mp4 URL, v18.1 Rule 2A requires it to stay M3U_LIVE
        assertEquals(ContentSourceType.M3U_LIVE, channels[1].sourceType)
        assertTrue(channels[1].isLiveTvChannel())
        assertFalse(channels[1].isVodMovie())
        assertFalse(channels[1].isSeriesEpisode())
        assertEquals(EntertainmentSection.LIVE_TV, channels[1].primarySection())
        assertEquals("2025", channels[1].extractReleaseYear())
        assertEquals("1080p", channels[1].extractQualityBadge())
    }

    @Test
    fun m3uAdversarialMovieAndSeriesChannelNamesAlwaysStayInLiveTv() {
        val adversarialPlaylist = """#EXTM3U
#EXTINF:-1 group-title="Movies",Bollywood Movies 24x7
https://stream.example/live/bollywood24x7.m3u8
#EXTINF:-1 group-title="Hollywood Movies",Hollywood Action Movies
https://stream.example/live/hollywood.ts
#EXTINF:-1 group-title="South Cinema",South Movie Mania (2025)
https://stream.example/live/south.mp4
#EXTINF:-1 group-title="Series",TMKOC 24x7
https://stream.example/live/tmkoc.m3u8
#EXTINF:-1 group-title="Hindi Series",CID Series Channel
https://stream.example/live/cid.m3u8
#EXTINF:-1 group-title="Web Series",Mirzapur Live S01E01
https://stream.example/live/mirzapur.mkv
#EXTINF:-1 group-title="Series",Web Series 24x7
https://stream.example/live/webseries24x7.m3u8
#EXTINF:-1 group-title="Drama",Drama Serial HD
https://stream.example/live/drama.m3u8
""".trimIndent()

        val channels = M3uParser.parse(adversarialPlaylist)
        assertEquals(8, channels.size)

        for (ch in channels) {
            assertEquals(ContentSourceType.M3U_LIVE, ch.sourceType)
            assertEquals(EntertainmentSection.LIVE_TV, ch.primarySection())
            assertTrue(ch.isLiveTvChannel())
            assertFalse(ch.isVodMovie())
            assertFalse(ch.isSeriesEpisode())
        }

        val seriesGroups = MediaCatalogEngine.buildXtreamSeriesGroups(channels)
        assertTrue(seriesGroups.isEmpty())
    }

    @Test
    fun separatesXtreamLiveVodMoviesAndSeriesByExplicitContentSourceType() {
        val xtreamLiveAdversarial = Channel(
            id = "live_101",
            number = 101,
            name = "Bollywood Movies 24x7",
            category = "Hindi Movies Live",
            streamUrl = "http://line.example:8080/live/u/p/101.m3u8",
            logoUrl = "https://cdn.example/live.png",
            epgId = "bollywood.live",
            backupUrl = "http://line.example:8080/live/u/p/101.ts",
            sourceType = ContentSourceType.XTREAM_LIVE
        )
        assertTrue(xtreamLiveAdversarial.isLiveTvChannel())
        assertFalse(xtreamLiveAdversarial.isVodMovie())
        assertFalse(xtreamLiveAdversarial.isSeriesEpisode())
        assertEquals(EntertainmentSection.LIVE_TV, xtreamLiveAdversarial.primarySection())

        val xtreamVodMovie = Channel(
            id = "vod_501",
            number = 1,
            name = "Night Silence (2024)",
            category = "BOLLYWOOD (2025-2026)",
            streamUrl = "http://line.example:8080/movie/u/p/501.mp4",
            logoUrl = "https://cdn.example/night_silence.jpg",
            epgId = "",
            backupUrl = "",
            sourceType = ContentSourceType.XTREAM_VOD_MOVIE,
            containerExtension = "mp4",
            releaseDate = "2024-10-31",
            rating = "4.7",
            plot = "A theatre actor whose health is failing gets admitted to a nursing home.",
            cast = "Maciej Damiecki, Zdzislaw Wardejn",
            director = "Bartosz M. Kowalski",
            trailerUrl = "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
            addedTimestamp = 1730332800L
        )
        assertFalse(xtreamVodMovie.isLiveTvChannel())
        assertTrue(xtreamVodMovie.isVodMovie())
        assertFalse(xtreamVodMovie.isSeriesEpisode())
        assertEquals(EntertainmentSection.MOVIES, xtreamVodMovie.primarySection())
        assertEquals("2024", xtreamVodMovie.extractReleaseYear())

        val movieDetailWithTrailer = VodMovieDetailInfo(
            streamId = "501",
            title = "Night Silence (2024)",
            posterUrl = xtreamVodMovie.logoUrl,
            releaseDate = xtreamVodMovie.releaseDate,
            rating = xtreamVodMovie.rating,
            genre = "Horror, Drama, Mystery",
            plot = xtreamVodMovie.plot,
            cast = xtreamVodMovie.cast,
            director = xtreamVodMovie.director,
            containerExtension = "mp4",
            trailerUrl = XtreamRepository().normalizeTrailerUrl("dQw4w9WgXcQ")
        )
        assertTrue(movieDetailWithTrailer.hasGenuineTrailer())
        assertEquals("https://www.youtube.com/watch?v=dQw4w9WgXcQ", movieDetailWithTrailer.trailerUrl)

        val movieDetailNoTrailer = movieDetailWithTrailer.copy(trailerUrl = "   ")
        assertFalse(movieDetailNoTrailer.hasGenuineTrailer())

        val xtreamSeriesCatalogEntry = Channel(
            id = "series_900",
            number = 1,
            name = "HURMAT (2026)",
            category = "PAK: HUM TV",
            streamUrl = "xtream://series/900",
            logoUrl = "https://cdn.example/hurmat.jpg",
            sourceType = ContentSourceType.XTREAM_SERIES,
            releaseDate = "2026-10-04",
            rating = "4.8",
            plot = "The world outside is never simple.",
            cast = "Dananeer Mobeen, Shahveer Jaffery",
            director = "Nadeem Siddique",
            seriesId = "900"
        )
        val builtGroups = MediaCatalogEngine.buildXtreamSeriesGroups(
            listOf(xtreamLiveAdversarial, xtreamVodMovie, xtreamSeriesCatalogEntry)
        )
        assertEquals(1, builtGroups.size)
        assertEquals("900", builtGroups.first().seriesId)
        assertEquals("xtream_series_900", builtGroups.first().seriesKey)

        val ep12 = Channel(
            id = "ep_900_12",
            number = 12,
            name = "HURMAT (2026) - S01E12",
            category = "PAK: HUM TV",
            streamUrl = "http://line.example:8080/series/u/p/9012.mp4",
            logoUrl = "https://cdn.example/hurmat.jpg",
            sourceType = ContentSourceType.XTREAM_SERIES_EPISODE,
            releaseDate = "2026-10-04",
            seriesId = "900"
        )
        val ep13 = ep12.copy(
            id = "ep_900_13",
            number = 13,
            name = "HURMAT (2026) - S01E13",
            streamUrl = "http://line.example:8080/series/u/p/9013.mp4"
        )
        val s2ep1 = ep12.copy(
            id = "ep_900_201",
            number = 1,
            name = "HURMAT (2026) - S02E01",
            streamUrl = "http://line.example:8080/series/u/p/9201.mp4"
        )

        assertTrue(ep12.isSeriesEpisode())
        assertFalse(ep12.isVodMovie())
        assertFalse(ep12.isLiveTvChannel())
        assertEquals(EntertainmentSection.SERIES, ep12.primarySection())

        val ep12Item = SeriesEpisodeItem(0, ep12, "900", "HURMAT (2026)", 1, 12, "HURMAT (2026) - S01E12")
        val ep13Item = SeriesEpisodeItem(1, ep13, "900", "HURMAT (2026)", 1, 13, "HURMAT (2026) - S01E13")
        val s2ep1Item = SeriesEpisodeItem(2, s2ep1, "900", "HURMAT (2026)", 2, 1, "HURMAT (2026) - S02E01")

        val seriesGroup = builtGroups.first().copy(
            seasons = mapOf(
                1 to listOf(ep12Item, ep13Item),
                2 to listOf(s2ep1Item)
            )
        )
        assertEquals(2, seriesGroup.seasonCount)
        assertEquals(3, seriesGroup.totalEpisodes)

        val nextAfterEp12 = MediaCatalogEngine.findNextEpisodeInSeries(
            group = seriesGroup,
            currentSeason = 1,
            currentEpisodeNumber = 12,
            currentEpisodeId = ep12.id
        )
        assertNotNull(nextAfterEp12)
        assertEquals("ep_900_13", nextAfterEp12?.channel?.id)

        val nextAfterEp13 = MediaCatalogEngine.findNextEpisodeInSeries(
            group = seriesGroup,
            currentSeason = 1,
            currentEpisodeNumber = 13,
            currentEpisodeId = ep13.id
        )
        assertNotNull(nextAfterEp13)
        assertEquals("ep_900_201", nextAfterEp13?.channel?.id)

        val prevBeforeS2Ep1 = MediaCatalogEngine.findPreviousEpisodeInSeries(
            group = seriesGroup,
            currentSeason = 2,
            currentEpisodeNumber = 1,
            currentEpisodeId = s2ep1.id
        )
        assertNotNull(prevBeforeS2Ep1)
        assertEquals("ep_900_13", prevBeforeS2Ep1?.channel?.id)

        val nextAfterLast = MediaCatalogEngine.findNextEpisodeInSeries(
            group = seriesGroup,
            currentSeason = 2,
            currentEpisodeNumber = 1,
            currentEpisodeId = s2ep1.id
        )
        assertNull(nextAfterLast)
    }

    @Test
    fun validatesVodSortOrdersContinueWatchingEligibilityAndLowMemoryMode() {
        assertEquals(VodSortOrder.NEW_TO_OLD, VodSortOrder.RECENTLY_ADDED.nextOrder())
        assertEquals(VodSortOrder.OLD_TO_NEW, VodSortOrder.NEW_TO_OLD.nextOrder())
        assertEquals(VodSortOrder.A_TO_Z, VodSortOrder.OLD_TO_NEW.nextOrder())
        assertEquals(VodSortOrder.Z_TO_A, VodSortOrder.A_TO_Z.nextOrder())
        assertEquals(VodSortOrder.RECENTLY_ADDED, VodSortOrder.Z_TO_A.nextOrder())

        assertEquals(LiveChannelSortOrder.A_TO_Z, LiveChannelSortOrder.CHANNEL_NUMBER.nextOrder())
        assertEquals(UiDensityMode.COMPACT, UiDensityMode.fromId("COMPACT"))
        assertEquals(6, UiDensityMode.COMPACT.tvPosterColumns)
        assertEquals(5, UiDensityMode.STANDARD.tvPosterColumns)
        assertEquals(4, UiDensityMode.CINEMATIC.tvPosterColumns)
        assertEquals(PerformanceMode.AUTO_ADAPTIVE, PerformanceMode.fromId("AUTO_ADAPTIVE", isLowRamDevice = true))

        val sidebarSpecial = VodCategorySidebarItem("FAVORITES / WATCHLIST", 4, isSpecialSection = true)
        assertTrue(sidebarSpecial.isSpecialSection)
        assertEquals(4, sidebarSpecial.count)

        val sidebarProvider = VodCategorySidebarItem("BOLLYWOOD (2025-2026)", 297, isSpecialSection = false)
        assertFalse(sidebarProvider.isSpecialSection)
        assertEquals(297, sidebarProvider.count)

        // Live TV entries must NEVER be resumable in Continue Watching
        val liveProgress = PlaybackProgressEntry(
            contentId = "live_101",
            positionMs = 600_000L,
            durationMs = 3_600_000L,
            updatedAtMs = 1000L,
            contentType = ContentSourceType.XTREAM_LIVE
        )
        assertFalse(liveProgress.isResumable())

        val m3uLiveProgress = liveProgress.copy(contentType = ContentSourceType.M3U_LIVE)
        assertFalse(m3uLiveProgress.isResumable())

        assertTrue(PerformanceMode.LOW_MEMORY.reducedAnimations)
        assertEquals(48 * 1024, PerformanceMode.LOW_MEMORY.maxPreloadSegmentBytes)
    }

    /**
     * Verifies Live TV Background Playback Controller, Typo-Tolerant SearchIntelligenceEngine,
     * PlaylistHealthEngine Duplicate Detection, BackupRestoreEngine (SXBK_V19), and PersonalizationEngine.
     */
    @Test
    fun verifiesLiveTvBackgroundControllerSmartSearchPlaylistHealthAndBackupEngine() {
        // 1. Live TV Background Playback Management
        LiveTvBackgroundPlaybackController.clearSuspendedState()
        assertTrue(
            LiveTvBackgroundPlaybackController.shouldSuspendLiveTvForSection(
                isLiveTvPlaybackMode = true,
                isInPictureInPictureMode = false,
                stopInBackgroundSettingEnabled = true
            )
        )
        assertFalse(
            LiveTvBackgroundPlaybackController.shouldSuspendLiveTvForSection(
                isLiveTvPlaybackMode = true,
                isInPictureInPictureMode = true,
                stopInBackgroundSettingEnabled = true
            )
        )
        assertFalse(
            LiveTvBackgroundPlaybackController.shouldSuspendLiveTvForSection(
                isLiveTvPlaybackMode = false,
                isInPictureInPictureMode = false,
                stopInBackgroundSettingEnabled = true
            )
        )
        LiveTvBackgroundPlaybackController.recordLiveTvSuspended(
            channelIndex = 7,
            channelId = "live_777",
            channelName = "Star Sports 1 HD",
            targetSectionName = "Movies"
        )
        val consumed = LiveTvBackgroundPlaybackController.consumeSuspendedState()
        assertTrue(consumed.wasSuspended)
        assertEquals(7, consumed.channelIndex)
        assertEquals("live_777", consumed.channelId)
        assertEquals("Star Sports 1 HD", consumed.channelName)
        assertFalse(LiveTvBackgroundPlaybackController.peekSuspendedState().wasSuspended)

        // 2. Typo-tolerant & multi-token SearchIntelligenceEngine
        assertTrue(SearchIntelligenceEngine.matchesSmartQuery("Star Sports 1 HD", "Sports", "sports star"))
        assertTrue(SearchIntelligenceEngine.matchesSmartQuery("Night Silence (2024)", "Bollywood", "bolywood"))
        assertTrue(SearchIntelligenceEngine.matchesSmartQuery("Mirzapur", "Hindi Series", "mirzpur"))
        assertTrue(SearchIntelligenceEngine.matchesSmartQuery("India News", "News", "505", channelNumberStr = "505"))
        assertFalse(SearchIntelligenceEngine.matchesSmartQuery("Cartoon Network", "Kids", "horror"))

        // 3. PlaylistHealthEngine & Smart Duplicate Detector
        val ch1 = Channel("ch_1", 1, "Star Sports 1 HD", "Sports", "https://cdn.example/ss1_a.m3u8", logoUrl = "https://cdn.example/l.png", epgId = "ss1", backupUrl = "https://cdn.example/ss1.ts")
        val ch2 = Channel("ch_2", 2, "  star sports 1 hd ", "Sports", "https://cdn.example/ss1_b.m3u8")
        val ch3 = Channel("ch_3", 3, "Aaj Tak HD", "News", "https://cdn.example/aaj.m3u8")
        val health = PlaylistHealthEngine.analyzeCatalogHealth(
            liveChannels = listOf(ch1, ch2, ch3),
            vodMovies = emptyList(),
            seriesGroups = emptyList(),
            hiddenChannelIds = setOf("ch_2")
        )
        assertEquals(3, health.totalLiveChannels)
        assertEquals(1, health.channelsWithBackupStream)
        assertEquals(1, health.channelsWithLogo)
        assertEquals(2, health.channelsMissingLogo)
        assertEquals(1, health.hiddenChannelsCount)
        assertEquals(1, health.duplicateGroups.size)
        assertEquals(2, health.duplicateGroups.first().channelIds.size)
        assertTrue(health.duplicateGroups.first().hasDistinctUrls)

        // 4. BackupRestoreEngine SXBK_V19 schema validation
        val invalidBackup = BackupRestoreEngine.validateBackupJson("{\"formatVersion\":\"OLD_V1\"}")
        assertFalse(invalidBackup.isValid)

        val validBackupJson = """{"formatVersion":"SXBK_V19","includesCredentials":false,"profiles":[],"liveFavorites":["ch_1"],"movieWatchlist":["vod_1"],"seriesWatchlist":[]}"""
        val validCheck = BackupRestoreEngine.validateBackupJson(validBackupJson)
        assertTrue(validCheck.isValid)
        assertEquals(1, validCheck.favoriteCount)
        assertEquals(1, validCheck.movieWatchlistCount)
    }

    @Test
    fun removesUtf8BomAndDeduplicatesIdenticalStreamUrls() {
        val playlist = "\uFEFF" + """#EXTM3U
#EXTINF:-1,First
https://stream.example/live.m3u8
#EXTINF:-1,Duplicate
https://stream.example/live.m3u8
"""
        val channels = M3uParser.parse(playlist)
        assertEquals(1, channels.size)
        assertEquals("First", channels.first().name)
    }

    @Test
    fun supportsReaderInputAndChannelLimit() {
        val playlist = """#EXTM3U
#EXTINF:-1,One
https://stream.example/1.m3u8
#EXTINF:-1,Two
https://stream.example/2.m3u8
"""
        val channels = M3uParser.parse(playlist.reader(), maxChannels = 1)
        assertEquals(1, channels.size)
        assertTrue(channels.first().number == 1)
    }

    @Test
    fun attachesSecondDistinctStreamUrlAsBackupUrlForSameChannelName() {
        val playlist = """#EXTM3U
#EXTINF:-1 group-title="Sports",Sports 18 HD
https://stream.example/primary.m3u8
#EXTINF:-1 group-title="Sports",Sports 18 HD
https://stream.example/backup.m3u8
"""
        val channels = M3uParser.parse(playlist)
        assertEquals(1, channels.size)
        assertEquals("https://stream.example/primary.m3u8", channels[0].streamUrl)
        assertEquals("https://stream.example/backup.m3u8", channels[0].backupUrl)
    }

    @Test
    fun normalizedPairHashIsCaseAndWhitespaceInsensitive() {
        val h1 = M3uParser.fnv1a64NormalizedPair("  Sports ", "  Star Sports 1 HD ")
        val h2 = M3uParser.fnv1a64NormalizedPair("sports", "star sports 1 hd")
        val h3 = M3uParser.fnv1a64NormalizedPair("Movies", "star sports 1 hd")
        assertEquals(h1, h2)
        assertNotEquals(h1, h3)
    }

    @Test
    fun handlesInvalidAndBrokenEntriesGracefully() {
        val playlist = """#EXTM3U
#EXTINF:-1
ftp://unsupported.example/file.ts
#EXTINF:-1 group-title="Movies",Valid Cinema HD
https://stream.example/cinema/live.m3u8
not_a_valid_url_line
""".trimIndent()
        val channels = M3uParser.parse(playlist)
        assertEquals(1, channels.size)
        assertEquals("Valid Cinema HD", channels[0].name)
        assertEquals(ContentSourceType.M3U_LIVE, channels[0].sourceType)
    }

    @Test
    fun extractsPipeAndExtVlcOptCustomHeadersAndRedactsCredentials() {
        val playlist = """#EXTM3U
#EXTINF:-1 group-title="VIP",VIP Sports 1
#EXTVLCOPT:http-user-agent=CustomPlayer/2.0
#EXTVLCOPT:http-referrer=https://portal.example/
#EXTVLCOPT:http-origin=https://origin.example
https://edge.example/live/ch1.m3u8?token=secret123|Authorization=Bearer%20tok999&Cookie=sid=abc
""".trimIndent()

        val channels = M3uParser.parse(playlist)
        assertEquals(1, channels.size)
        assertEquals("https://edge.example/live/ch1.m3u8?token=secret123", channels[0].streamUrl)

        val headers = NetworkClient.headersForUrl(channels[0].streamUrl)
        assertEquals("CustomPlayer/2.0", headers["User-Agent"])
        assertEquals("https://portal.example/", headers["Referer"])
        assertEquals("https://origin.example", headers["Origin"])
        assertEquals("Bearer tok999", headers["Authorization"])
        assertEquals("sid=abc", headers["Cookie"])

        val redacted = NetworkClient.redactSensitiveUrl(
            "http://line.server.com:8080/live/harindra/mySecretPass/402.m3u8?token=xyz987&password=p1"
        )
        assertFalse(redacted.contains("mySecretPass"))
        assertFalse(redacted.contains("xyz987"))
        assertFalse(redacted.contains("p1"))
        assertTrue(redacted.contains("****"))

        val redactedVod = NetworkClient.redactSensitiveUrl(
            "http://line.server.com:8080/movie/harindra/vodPass99/901.mp4"
        )
        assertFalse(redactedVod.contains("vodPass99"))
        assertTrue(redactedVod.contains("****"))
    }

    @Test
    fun parses30kAnd60kLargePlaylistsWithinLimit() {
        val totalToGenerate = 60_000
        val syntheticReader = object : Reader() {
            private var currentChannel = 0
            private var buffer = "#EXTM3U\n"
            private var pos = 0

            override fun read(cbuf: CharArray, off: Int, len: Int): Int {
                if (pos >= buffer.length) {
                    if (currentChannel >= totalToGenerate) return -1
                    currentChannel++
                    buffer = "#EXTINF:-1 group-title=\"Group${currentChannel % 20}\",Channel $currentChannel\nhttps://cdn.example/live/$currentChannel.m3u8\n"
                    pos = 0
                }
                val toCopy = (buffer.length - pos).coerceAtMost(len)
                buffer.toCharArray(cbuf, off, pos, pos + toCopy)
                pos += toCopy
                return toCopy
            }

            override fun close() {}
        }

        var firstBatchCount = 0
        val parsed = M3uParser.parse(
            reader = syntheticReader,
            maxChannels = 60_000,
            onFirstBatch = { firstBatchCount = it.size }
        )
        assertEquals(40, firstBatchCount)
        assertEquals(60_000, parsed.size)
        assertEquals("Channel 1", parsed.first().name)
        assertEquals("Channel 60000", parsed.last().name)
        assertEquals(ContentSourceType.M3U_LIVE, parsed.first().sourceType)
    }

    @Test
    fun detectsStreamFormatsAndParsesHlsPreloadTargetsWithTokenPreservation() {
        assertEquals(StreamPreFetcher.StreamFormat.HLS, StreamPreFetcher.detectStreamFormat("https://cdn.example/live/ch1.m3u8?token=abc"))
        assertEquals(StreamPreFetcher.StreamFormat.DASH, StreamPreFetcher.detectStreamFormat("https://cdn.example/live/manifest.mpd"))
        assertEquals(StreamPreFetcher.StreamFormat.RTSP, StreamPreFetcher.detectStreamFormat("rtsp://192.168.1.10:554/live"))
        assertEquals(StreamPreFetcher.StreamFormat.MPEG_TS, StreamPreFetcher.detectStreamFormat("http://line.server.com:8080/live/user/pass/101.ts"))

        val masterM3u8 = """#EXTM3U
#EXT-X-STREAM-INF:BANDWIDTH=12000000,RESOLUTION=3840x2160
4k/index.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=4500000,RESOLUTION=1920x1080
1080p/index.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=2200000,RESOLUTION=1280x720
720p/index.m3u8
""".trimIndent()

        val masterPlan = StreamPreFetcher.parseHlsPlaylistTargets(
            "https://cdn.example/live/master.m3u8?wmsAuthSign=tok777",
            masterM3u8
        )
        assertTrue(masterPlan.isMasterPlaylist)
        assertEquals("https://cdn.example/live/1080p/index.m3u8?wmsAuthSign=tok777", masterPlan.variantPlaylistUrl)

        val mediaM3u8 = """#EXTM3U
#EXT-X-TARGETDURATION:4
#EXT-X-MAP:URI="init.mp4"
#EXTINF:4.0,
seg100.m4s
#EXTINF:4.0,
seg101.m4s
#EXTINF:4.0,
seg102.m4s
""".trimIndent()

        val mediaPlan = StreamPreFetcher.parseHlsPlaylistTargets(
            "https://cdn.example/live/1080p/index.m3u8?wmsAuthSign=tok777",
            mediaM3u8
        )
        assertFalse(mediaPlan.isMasterPlaylist)
        assertEquals("https://cdn.example/live/1080p/init.mp4?wmsAuthSign=tok777", mediaPlan.initSegmentUrl)
        assertNotNull(mediaPlan.firstMediaSegmentUrl)
        assertEquals("https://cdn.example/live/1080p/seg101.m4s?wmsAuthSign=tok777", mediaPlan.firstMediaSegmentUrl)
    }

    @Test
    fun classifiesHttpAuthAndServerErrorsAndValidatesMediaSegmentBytes() {
        assertNull(StreamPreFetcher.classifyHttpStatus(200))
        assertNull(StreamPreFetcher.classifyHttpStatus(206))
        assertEquals(StreamPreFetcher.PreloadState.AUTH_ERROR, StreamPreFetcher.classifyHttpStatus(401))
        assertEquals(StreamPreFetcher.PreloadState.AUTH_ERROR, StreamPreFetcher.classifyHttpStatus(403))
        assertEquals(StreamPreFetcher.PreloadState.NOT_FOUND, StreamPreFetcher.classifyHttpStatus(404))
        assertEquals(StreamPreFetcher.PreloadState.RATE_LIMITED, StreamPreFetcher.classifyHttpStatus(429))
        assertEquals(StreamPreFetcher.PreloadState.SERVER_ERROR, StreamPreFetcher.classifyHttpStatus(503))
        assertEquals(StreamPreFetcher.PreloadState.TIMEOUT, StreamPreFetcher.classifyException(SocketTimeoutException("Read timed out")))
        assertEquals(StreamPreFetcher.PreloadState.CANCELLED, StreamPreFetcher.classifyException(IOException("Canceled")))

        val tsPacket = ByteArray(376).apply {
            this[0] = 0x47
            this[188] = 0x47
        }
        assertTrue(StreamPreFetcher.isValidMediaSegmentBytes(tsPacket, "video/mp2t"))

        val fmp4Init = byteArrayOf(0, 0, 0, 24, 'f'.code.toByte(), 't'.code.toByte(), 'y'.code.toByte(), 'p'.code.toByte())
        assertTrue(StreamPreFetcher.isValidMediaSegmentBytes(fmp4Init, "video/mp4"))

        val htmlError = "<html><body>403 Forbidden</body></html>".toByteArray(Charsets.UTF_8)
        assertFalse(StreamPreFetcher.isValidMediaSegmentBytes(htmlError, "text/html"))
        assertFalse(StreamPreFetcher.isValidMediaSegmentBytes(htmlError, "video/mp2t"))
    }

    @Test
    fun verifiesSaltedParentalPinHashPerformanceModesAndProgressCalculation() {
        val salt = "0123456789abcdef0123456789abcdef"
        val hash = ProfileStore.computeSaltedPinHash("2580", salt)
        assertTrue(ProfileStore.verifySaltedPinHash("2580", salt, hash))
        assertFalse(ProfileStore.verifySaltedPinHash("1234", salt, hash))
        assertFalse(ProfileStore.verifySaltedPinHash("258", salt, hash))

        assertEquals(PerformanceMode.AUTO_ADAPTIVE, PerformanceMode.fromId(null, isLowRamDevice = true))
        assertEquals(PerformanceMode.LOW_MEMORY, PerformanceMode.fromId("LOW_MEMORY", isLowRamDevice = false))

        val prog = PlaybackProgressEntry(
            contentId = "vod_9001",
            positionMs = 1_800_000L,
            durationMs = 3_600_000L,
            updatedAtMs = 1000L
        )
        assertEquals(50, prog.progressPercent())
        assertTrue(prog.isResumable())
        assertFalse(prog.isCompleted())

        val completedProg = PlaybackProgressEntry(
            contentId = "vod_9001",
            positionMs = 3_500_000L,
            durationMs = 3_600_000L,
            updatedAtMs = 2000L
        )
        assertEquals(97, completedProg.progressPercent())
        assertTrue(completedProg.isCompleted())
        assertFalse(completedProg.isResumable())

        assertEquals(
            "http://line.server.com:8080",
            XtreamRepository().normalizeServerBaseUrl("  \uFEFFline.server.com:8080/ ")
        )
        assertEquals("starsports1", XmltvParser.normalizeEpgKey("Star_Sports_1_HD.in"))
        val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        val tsMs = XmltvParser.parseXmltvTimestampFast("20261118120000 +0530", cal)
        assertTrue(tsMs > 0L)
    }

    @Test
    fun cancelsStaleGenerationAndTracksPreloadMissFallbackCleanly() {
        val genBefore = StreamPreFetcher.currentGenerationId()
        StreamPreFetcher.notifyChannelSwitched("https://cdn.example/live/ch10.m3u8", forwardDirection = true)
        val genAfter = StreamPreFetcher.currentGenerationId()
        assertTrue(genAfter > genBefore)

        val missedSource = StreamPreFetcher.consumePreparedMediaSource("https://cdn.example/live/unpreloaded.m3u8")
        assertNull(missedSource)
    }

    @Test
    fun verifiesEncryptedBackupRoundTripAndAudioDelayBounds() {
        val sampleJson = """{"formatVersion":"SXBK_V20","includesCredentials":false,"profiles":[],"liveFavorites":["ch_9"],"movieWatchlist":[],"seriesWatchlist":[]}"""
        val encrypted = BackupRestoreEngine.encryptBackupWithPassword(sampleJson, "ram190secret")
        assertTrue(encrypted.startsWith(BackupRestoreEngine.ENCRYPTED_BACKUP_PREFIX))
        assertEquals(sampleJson, BackupRestoreEngine.decryptBackupWithPassword(encrypted, "ram190secret"))
        assertNull(BackupRestoreEngine.decryptBackupWithPassword(encrypted, "wrong_password"))
        assertNull(BackupRestoreEngine.decryptBackupWithPassword("SXBK_ENC1:deadbeef", "ram190secret"))

        val v20Check = BackupRestoreEngine.validateBackupJson(sampleJson)
        assertTrue(v20Check.isValid)
        assertEquals(1, v20Check.favoriteCount)

        val delayProc = AudioDelayProcessor()
        assertEquals(0, delayProc.getDelayMs())
        delayProc.setDelayMs(250)
        assertEquals(250, delayProc.getDelayMs())
        delayProc.setDelayMs(9999)
        assertEquals(AudioDelayProcessor.MAX_DELAY_MS, delayProc.getDelayMs())
        delayProc.setDelayMs(-50)
        assertEquals(0, delayProc.getDelayMs())
        delayProc.clearDelayBuffer()
    }

    @Test
    fun verifiesV20DeviceOptimizationModesRecycleBinAndIndependentWorkManagerNaming() {
        val low512 = DeviceOptimizationProfile.resolve(PerformanceMode.LOW_MEMORY, totalRamMb = 512L, isLowRamDevice = true)
        assertEquals(PerformanceMode.LOW_MEMORY, low512.mode)
        assertTrue(low512.reducedGlassEffects)
        assertEquals(12, low512.maxPosterCacheMb)

        val high4gb = DeviceOptimizationProfile.resolve(PerformanceMode.HIGH_PERFORMANCE_4GB, totalRamMb = 4096L, isLowRamDevice = false)
        assertEquals(PerformanceMode.HIGH_PERFORMANCE_4GB, high4gb.mode)
        assertFalse(high4gb.reducedGlassEffects)
        assertEquals(48, high4gb.maxPosterCacheMb)
        assertTrue(high4gb.maxChannelCacheItems >= low512.maxChannelCacheItems)

        // Memory-pressure safeguard forces LOW_MEMORY even when 4GB mode is selected
        val pressureFallback = DeviceOptimizationProfile.resolve(
            PerformanceMode.HIGH_PERFORMANCE_4GB,
            totalRamMb = 4096L,
            isLowRamDevice = false,
            underMemoryPressure = true
        )
        assertEquals(PerformanceMode.LOW_MEMORY, pressureFallback.mode)

        // RecycleBinEntry retention check
        val now = 1_750_000_000_000L
        val fresh = RecycleBinEntry("PROFILE_1", "PROFILE", "My IPTV", "{}", deletedAtEpochMs = now - 86_400_000L)
        val old = RecycleBinEntry("PROFILE_2", "PROFILE", "Old IPTV", "{}", deletedAtEpochMs = now - (31L * 86_400_000L))
        assertFalse(fresh.isExpired(nowMs = now, retentionDays = 30))
        assertTrue(old.isExpired(nowMs = now, retentionDays = 30))

        // Independent per-profile & per-playlist WorkManager unique names
        val wA1 = PlaylistRefreshWorker.uniqueWorkName("profileA", "playlist1")
        val wA2 = PlaylistRefreshWorker.uniqueWorkName("profileA", "playlist2")
        val wB3 = PlaylistRefreshWorker.uniqueWorkName("profileB", "playlist3")
        assertNotEquals(wA1, wA2)
        assertNotEquals(wA1, wB3)
        assertNotEquals(wA2, wB3)
    }
}
